const botao = document.querySelector("#botao");
const mensagem = document.querySelector("#mensagem");

botao.addEventListener("click", () => {
  mensagem.textContent = "HTML estrutura, CSS estiliza e JavaScript adiciona comportamento.";
});
