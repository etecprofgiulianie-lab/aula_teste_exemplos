# Exemplo para a aula-teste de Front-end

Prof.ª Giulianie Aparecida Machado Ferreira

## Arquivos principais

- `index.html`: estrutura e conteúdo da página.
- `style.css`: apresentação visual.
- `script.js`: resposta ao clique do botão.

Os três arquivos devem permanecer na mesma pasta. O projeto funciona localmente, sem servidor, banco de dados, internet ou instalação de bibliotecas.

## Como abrir no Visual Studio Code

1. Extraia o ZIP antes de começar. Não abra os arquivos diretamente dentro do ZIP.
2. No VS Code, selecione **Arquivo > Abrir Pasta** e abra a pasta `exemplo-front-end`.
3. Abra as abas `index.html`, `style.css` e `script.js` nessa ordem.
4. Aumente a fonte em **Configurações > Editor: Font Size**, por exemplo para 22 ou 24, e ajuste à resolução do projetor.
5. Use **Alt+Z** para ativar a quebra de linhas longas. O atalho pode variar conforme a configuração do VS Code.
6. No Explorador de Arquivos do Windows, abra `index.html` com Chrome, Edge ou Firefox.

O editor serve para escrever o código. O resultado aparece no navegador. Live Server é opcional e não é necessário para este exemplo.

## Demonstração em três momentos

As versões da pasta `etapas` usam o mesmo conteúdo para isolar as responsabilidades. Elas evitam apagar ou comentar código diante da banca.

1. **HTML:** mostre o arquivo principal `index.html` no VS Code e abra `etapas/01-html.html` no navegador. A página contém textos, links e botão com os estilos padrão do navegador. Ela ainda não possui a resposta personalizada ao clique.
2. **CSS:** mostre `style.css` no VS Code e abra `etapas/02-html-css.html`. O mesmo conteúdo recebe cores, fonte e espaçamento. Essa versão também não carrega o script.
3. **JavaScript:** mostre `script.js` no VS Code e abra `index.html`. Clique em **Conhecer a oficina**. O texto do parágrafo muda para “HTML estrutura, CSS estiliza e JavaScript adiciona comportamento.”

Para repetir a demonstração, atualize a página. Não há inscrição real, envio de dados, persistência ou autenticação.

## Alteração curta opcional

Em `style.css`, na regra `button`, troque `background: #0e7490;` por `background: #7c3aed;`. Salve com Ctrl+S e atualize o navegador. O conteúdo do HTML permanece igual e a cor do botão muda. Essa alteração é opcional e cabe no tempo reservado ao CSS.

## Antes da apresentação

Teste os arquivos no computador e no navegador que utilizará. Deixe as abas de código e as três versões da página abertas. Teste a projeção e o tamanho da fonte. Leve os arquivos em pendrive. A apresentação contém trechos de código como apoio caso seja necessário continuar sem a demonstração ao vivo.

O código já está pronto. Durante os 15 minutos, explique os blocos principais em vez de digitar todos os arquivos.
