# Roteiro da aula-teste de Front-end

**Disciplina:** Tecnologias para Internet  
**Tema:** HTML, CSS e JavaScript  
**Docente:** Giulianie Aparecida Machado Ferreira  
**Público considerado:** estudantes iniciantes de graduação  
**Duração:** 15 minutos, com encerramento planejado em 14min30s  
**Pré-requisitos:** uso básico do navegador e de arquivos  
**Recursos:** PowerPoint, VS Code e navegador, sem dependência de internet

## Objetivo de aprendizagem

Ao final da aula, o estudante deverá distinguir as funções de HTML, CSS e JavaScript e explicar como um clique pode atualizar um texto na página.

## Organização do tempo

| Slide | Tema | Intervalo |
|---|---|---|
| 1 | Apresentação e objetivo | 0:00–0:40 |
| 2 | Conceito de site | 0:40–1:30 |
| 3 | Partes de uma página | 1:30–2:30 |
| 4 | Conceito de Front-end | 2:30–3:20 |
| 5 | Conceito e sintaxe de HTML | 3:20–4:10 |
| 6 | Estrutura do documento HTML | 4:10–4:50 |
| 7 | Demonstração de HTML no VS Code | 4:50–6:00 |
| 8 | Conceito e sintaxe de CSS | 6:00–6:50 |
| 9 | Demonstração de CSS no VS Code | 6:50–8:20 |
| 10 | Conceito de JavaScript | 8:20–9:10 |
| 11 | Demonstração de JavaScript no VS Code | 9:10–12:10 |
| 12 | Integração dos arquivos | 12:10–13:00 |
| 13 | Verificação e síntese | 13:00–14:30 |
| — | Margem para transições | 14:30–15:00 |

Os tempos incluem as alternâncias entre slides, VS Code e navegador. As notas do apresentador no PowerPoint também trazem orientações para cada slide.

## Fala de apoio por slide

### 1. Tecnologias para Internet

“Bom dia. Sou a professora Giulianie. Hoje vamos compreender o papel do HTML, do CSS e do JavaScript na construção de uma página. Ao final, vocês deverão identificar qual tecnologia usar para organizar um conteúdo, mudar sua aparência ou responder a um clique.”

Pergunta inicial: “Quando você clica em um botão de uma página, como essa ação pode mudar o que aparece na tela?” Não aguarde uma resposta longa. Retome a pergunta na demonstração.

### 2. O que é um site?

“Um site reúne páginas e recursos organizados. No site de uma instituição, por exemplo, podemos encontrar páginas de início, cursos e contato. Cada página é um documento que o navegador apresenta. Um site também pode ter uma única página, como a que usaremos hoje.”

Distinga o exemplo local de uma publicação: o arquivo permite estudar a página, mas não significa que ela já esteja disponível publicamente na Web.

### 3. Partes de uma página

“É comum encontrar um cabeçalho, uma navegação, o conteúdo principal e um rodapé. O HTML oferece elementos que dão significado a essas regiões: header, nav, main, section e footer. Essa organização ajuda a compreender a estrutura do documento.”

Mostre no código a relação de uma seção dentro do conteúdo principal. Não apresente essas regiões como obrigatórias em todos os sites.

### 4. O que é Front-end?

“Front-end é a interface com a qual o usuário interage. Na nossa página, o HTML organiza o conteúdo, o CSS controla a apresentação e o JavaScript programa uma resposta ao clique. O navegador reúne essas tecnologias para apresentar a interface.”

Evite afirmar que toda interação depende de JavaScript: links e controles HTML já possuem comportamentos nativos.

### 5. HTML

“HTML significa linguagem de marcação de hipertexto. Usamos elementos para indicar o significado do conteúdo. Neste exemplo, h2 indica um título de seção. A tag de abertura, o conteúdo e a tag de fechamento compõem esse elemento.”

Explique que HTML é uma linguagem de marcação. Não o classifique como linguagem de programação. Nem todos os elementos usam fechamento, como meta e link.

### 6. Estrutura do documento HTML

“O documento começa com a declaração do tipo HTML. O elemento html envolve o documento. No head ficam informações como o título da aba e as referências a outros arquivos. No body está o conteúdo da página.”

Diferencie head de header: o primeiro reúne informações do documento, o segundo representa um cabeçalho no conteúdo. O arquivo completo inclui charset UTF-8, viewport e idioma pt-BR.

### 7. HTML no VS Code

Abra `index.html` já posicionado no botão e no parágrafo.

“Aqui temos um botão e um parágrafo. O id identifica cada elemento de forma única na página. Essas identificações permitirão ao JavaScript localizar o botão e a mensagem.”

Abra `etapas/01-html.html` no navegador. Mostre que o conteúdo já aparece, com a apresentação padrão do navegador. Não clique esperando a atualização, pois essa etapa não carrega o script.

Se perguntarem sobre `aria-live="polite"`, explique que a região permite anunciar mudanças de texto a tecnologias assistivas, respeitando o momento adequado de leitura. Não se aprofunde nesse atributo durante a exposição.

### 8. CSS

“CSS significa folhas de estilo em cascata. Uma regra começa com um seletor, que indica os elementos aos quais ela se aplica. Entre chaves, escrevemos as propriedades e seus valores. Nesta regra, button seleciona os botões, background é a propriedade e o código hexadecimal define a cor.”

Mostre a referência à folha externa por meio do elemento link no HTML.

### 9. CSS no VS Code

Abra `style.css` na regra `button`.

“Com CSS definimos a cor do fundo, a cor do texto e o espaço interno do botão. O HTML continua com o mesmo conteúdo.”

Abra `etapas/02-html-css.html` para mostrar o resultado com os estilos. Se o tempo permitir, altere apenas a cor do botão conforme o README, salve e atualize. Não digite toda a folha de estilos. Os recursos adicionais do arquivo, como clamp e focus-visible, podem ser comentados se a banca perguntar.

### 10. JavaScript

“JavaScript é uma linguagem de programação. No navegador, ela pode acessar a representação do documento, chamada DOM, para responder a eventos e atualizar a interface. No nosso exemplo, o clique será o evento e a atualização da mensagem será a resposta.”

### 11. JavaScript no VS Code

Abra `script.js` e explique em blocos:

1. `document.querySelector("#botao")` localiza o elemento cujo id é botao. A segunda seleção encontra o parágrafo da mensagem. `const` guarda as referências para uso no programa.
2. `addEventListener("click", ...)` registra a função de resposta ao clique.
3. `mensagem.textContent` define o novo texto. A função executa quando o evento ocorre, e não apenas quando registramos o listener.

Fala sugerida: “Antes de clicar, qual arquivo vocês esperam que controle a nova mensagem?”

Abra a página principal `index.html` no navegador e clique em **Conhecer a oficina**.

“O JavaScript localizou o parágrafo e alterou seu texto. Não precisamos recarregar a página para ver a atualização. Este exemplo não envia dados nem efetua uma inscrição.”

Se houver tempo, use Tab para alcançar o botão e Enter para acioná-lo. Recarregar a página restaura o texto inicial.

### 12. Integração dos arquivos

“O HTML referencia a folha de estilos e o script. Como os arquivos estão na mesma pasta, os caminhos usam apenas os nomes dos arquivos. O atributo defer permite executar esse script externo após a análise do HTML. Assim, o botão e o parágrafo já existem quando o código procura por eles.”

Finalize a distinção: “Escrevemos no VS Code. O navegador apresenta o documento e executa o JavaScript.”

### 13. Verificação da aprendizagem

Pergunte qual arquivo deve ser alterado para:

1. Trocar o título inicial da oficina. Resposta esperada: `index.html`.
2. Mudar a cor do botão. Resposta esperada: `style.css`.
3. Exibir outra mensagem após um clique. Resposta esperada: `script.js`.

“Portanto, HTML organiza o conteúdo, CSS define sua apresentação e JavaScript programa a interação. No exemplo que acabamos de executar, cada arquivo tem uma responsabilidade clara.”

Essa classificação corresponde ao exemplo: JavaScript também pode alterar textos e estilos em tempo de execução.

## Preparação e ensaio

- Treine com cronômetro e com os arquivos já abertos. Encerre até 14min30s.
- Abra previamente as três abas no VS Code e as três versões no navegador.
- Use fonte ampliada no editor e mantenha a quebra de linhas ativada.
- Evite instalar extensões ou ferramentas durante a aula. A execução local é suficiente.
- Caso o tempo fique curto, pule a alteração opcional da cor e mantenha o clique final e a verificação da aprendizagem.
- Se houver problema na alternância de janelas, continue pelos trechos de código nos slides. O resultado esperado do JavaScript aparece no slide 11.

## Perguntas possíveis da banca

**Por que separar os arquivos?** Para organizar as responsabilidades e facilitar a leitura e a manutenção do exemplo.

**Por que usar addEventListener?** Para registrar a resposta ao evento no arquivo JavaScript, sem inserir o código da interação como atributo no HTML.

**Por que textContent?** Porque o objetivo é alterar texto simples, sem interpretar marcação HTML.

**Por que defer?** Porque o script externo precisa acessar elementos do documento depois que o HTML tiver sido analisado.

**Isso já é um site publicado?** É uma página funcional local. Publicá-la exige hospedagem ou outro serviço de disponibilização na Web.

**O que acontece sem CSS?** O conteúdo continua disponível com os estilos padrão do navegador.

**O que acontece sem JavaScript?** A página mantém seu conteúdo, estilos e comportamentos nativos, mas perde a atualização personalizada da mensagem.

## Referências de apoio

Documentação MDN, consultada em 20/10/2026:

- HTML: https://developer.mozilla.org/pt-BR/docs/Web/HTML
- Estrutura de documentos: https://developer.mozilla.org/pt-BR/docs/Learn_web_development/Core/Structuring_content/Structuring_documents
- CSS: https://developer.mozilla.org/pt-BR/docs/Web/CSS
- JavaScript: https://developer.mozilla.org/pt-BR/docs/Web/JavaScript
- Elemento script e defer: https://developer.mozilla.org/pt-BR/docs/Web/HTML/Reference/Elements/script
- Registro de eventos: https://developer.mozilla.org/pt-BR/docs/Web/API/EventTarget/addEventListener
